#!/bin/bash
#compruebo si el proceso esta en ejecucion
if [ -z "$1" ]; then
	echo "Debe proporcionar el nombre del proceso a monitorear"
	exit 1
fi
proceso="$1"
echo "Verificando proceso $proceso..."
if pgrep -x "$proceso" > /dev/null; then
	echo "El proceso $proceso esta en ejecucion"
else
	echo "El proceso $proceso no esta en ejecucion. Enviando correo a root"
	echo "El proceso $proceso no esta en ejecucion en $(date)" | mail -s "Alerta: Proceso $proceso no esta en ejecucion" root
fi
